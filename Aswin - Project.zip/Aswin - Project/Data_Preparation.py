import pandas as pd
import numpy as np


# Reading excel file from the directory folder
def reading_excel():
    df = pd.read_excel('test_DataSet.xlsx')
    return df

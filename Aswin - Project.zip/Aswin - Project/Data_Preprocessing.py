import pandas as pd
import numpy as np

def data_preprocess(data):
    s1 = nullvaluetreatment(data) # Continue with the null value treatment
    s2 = remove_duplicates(s1)
    return s2

def nullvaluetreatment(data):
    df = data.copy()  # Make a copy of the DataFrame to avoid modifying the original data
    #print('Shape of dataframe before null values:', df.shape)
    counter = df.isnull().sum()  # Count the number of null values in each column
    #print(counter)
    # Almost 25000 around null values in found in dataset. we will lose info if we drop directly.
    # replacing null values with mean of the respective column to avoid data loss.
    for column in df.columns:
        if df[column].isnull().any():
            mean_value = df[column].mean()  # Compute the mean of the feature
            df[column].fillna(mean_value, inplace=True)  # Replace null values with the mean
    #print('Shape of dataframe after replacing null values:', df.shape)
    #print(df.isnull().sum())

    return df

def remove_duplicates(s1):

    sam = s1.copy()  # Make a copy of the DataFrame to avoid modifying the original data
    #print('Shape of dataframe before removing duplicates:', sam.shape)
    duplicates_count = sam.duplicated().sum()  # Count the number of duplicates
    #print(f"Found {duplicates_count} duplicates.")
    sam.drop_duplicates(inplace=True)  # Drop the duplicates
    #print('Shape of dataframe after removing duplicates:', sam.shape)

    return sam

def check_multicollinearity(s2, threshold=0.8):
    # Calculate the correlation matrix
    dataset=s2.copy()
    corr_matrix = dataset.corr()


    # Create a mask to hide the upper triangle of the correlation matrix
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

    # Plot the correlation matrix as a heatmap
    #plt.figure(figsize=(10, 8))
    #sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='coolwarm')

    # Find highly correlated features
    correlated_features = []
    for i in range(len(corr_matrix.columns)):
        for j in range(i+1, len(corr_matrix.columns)):
            if corr_matrix.iloc[i, j] >= threshold:
                feature_i = corr_matrix.columns[i]
                feature_j = corr_matrix.columns[j]
                correlation_value = corr_matrix.iloc[i, j]
                correlated_features.append((feature_i, feature_j, correlation_value))

    # Display the highly correlated features
    """if correlated_features:
        print("Highly correlated features:")
        for feature_i, feature_j, correlation_value in correlated_features:
            print(f"{feature_i} - {feature_j}: {correlation_value}")"""


    return dataset

def drop_highly_correlated_features(s2):
        df=s2.copy()
        df.drop('obddistance', axis=1, inplace=True)
        #dropping obd distance from the dataframe as runtime showing proper info and uniqueness.
        df.drop('engine_torque_percent', axis=1, inplace=True)
        df.reset_index(inplace=True)
        #dropping engine_torque_percent from df, it is collinear with 2 different columns. So its better to drop this one.
        #print(df.columns)
        #print(df.shape)
        return df


def remove_outliers(s3,threshold):

    df=s3.copy()
    #print(df.shape)
    z_scores = pd.DataFrame()
    columns=df.columns
    #print('cols:',columns)
    for column in columns:
        z_scores[column] = np.abs((df[column] - df[column].mean()) / df[column].std())

    # Identify outliers based on the threshold(3)
    outlier_indices = np.where(z_scores > threshold)

    # Removing rows which containing outliers
    df.drop(outlier_indices[0],axis=0,inplace=True)
    df.reset_index()
    #print('No of Outliers found from 3 S.D are',len(outlier_indices[0]))
    #print(df.shape)
    #print(df.columns)
    df.to_csv('preprocessed_dataframe.csv', index=False)
    return df


data = pd.read_csv('featureengineering_df.csv')
st1=data_preprocess(data)
st2=remove_duplicates(st1)
st3=check_multicollinearity(st2,threshold=0.8)
st4=drop_highly_correlated_features(st3)
st5=remove_outliers(st4,threshold=3)

import Data_Preparation
import datetime
import pandas as pd

"""The timestamp value "1680763413" represents a Unix timestamp. Unix timestamps are a way to 
represent dates and times as a single numeric value.To convert this Unix 
timestamp to a human-readable format we need to use datetime module."""

def convert_timestamps_to_datetime(df, timestamp_column):
    global dt
    for timestamp in df[timestamp_column]:
        dt = datetime.datetime.fromtimestamp(timestamp)
        return dt

# creating new column Timestamp which we got as result from dt.

def newcol_dataframe(dt):
    df['Timestamp'] =''
    df['Timestamp']=dt
    #print(df.columns)
    #print(df['Timestamp'][2])
    return df

# Converting the timestamp column into date,month,year,hour,minute and second for better analysis.

def conversion(df):

    df['year'] = df['Timestamp'].dt.year
    df['month'] = df['Timestamp'].dt.month
    df['day'] = df['Timestamp'].dt.day
    df['hour'] = df['Timestamp'].dt.hour
    df['minute'] = df['Timestamp'].dt.minute
    df['second'] = df['Timestamp'].dt.second
    # print(df.head(2))

    return df

# Here we are dropping unique id column as it is talking about single ID and ts column also.

def featuredrop(df):
    if df['uniqueid'].nunique() == 1:
        df.drop('uniqueid', axis=1, inplace=True)
    df.drop('ts', axis=1, inplace=True)
    df.drop('Timestamp', axis=1, inplace=True)
    #print(df.columns)
    df.to_csv('featureengineering_df.csv', index=False)
    return df

# We don't have clear evidence or info to drop other columns. so in further analysis if we find any we will drop

# Functions Calling
# Call the reading_excel() function to get the DataFrame
df = Data_Preparation.reading_excel()
# Iterate over each value in the 'ts' column and convert to datetime objects
convert_timestamps_to_datetime(df,'ts')
# Creating new column in dataframe
newcol_dataframe(dt)
# converting timestamp column to required format for further analysis
conversion(df)
# Dropping unreuired columns
df=featuredrop(df)
